package com.udemy.universidadJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversidadJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversidadJavaApplication.class, args);
	}

}
