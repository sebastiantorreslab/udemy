package com.udemy.universidadJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversidadJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
